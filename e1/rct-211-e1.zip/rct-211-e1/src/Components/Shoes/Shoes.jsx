import React from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getShoesFailure,
  getShoesRequest,
  getShoesSuccess,
} from "../../Redux/action";

const Shoes = () => {
  return <div>{/* Map through the shoes list here */}</div>;
};

export default Shoes;

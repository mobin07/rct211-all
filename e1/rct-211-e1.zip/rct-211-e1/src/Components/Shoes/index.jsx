export { default as Shoes } from "./Shoes";

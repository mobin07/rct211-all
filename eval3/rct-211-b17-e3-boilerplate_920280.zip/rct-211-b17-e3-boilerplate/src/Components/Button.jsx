export const Button = ({ colorScheme, variant, size }) => {
  return <button></button>;
};

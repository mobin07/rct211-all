export const Pagination = ({ total, selected, onPageChange }) => {
  return <div className="pageContainer"></div>;
};

export const useCounter = (init) => {};
